package Latihan2;

public class Makanan extends Hidangan{
    public String disantap(){
        return this.getNamaHidangan() + " dimakan";
    }
}
