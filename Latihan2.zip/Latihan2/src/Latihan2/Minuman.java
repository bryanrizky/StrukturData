package Latihan2;

public class Minuman extends Hidangan{
    public String disantap(){
        return this.getNamaHidangan() + " diminum";
    }
}